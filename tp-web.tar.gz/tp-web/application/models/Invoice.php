<?php

class Invoice extends CI_Model{

    public function basket_to_invoice($user_id, $basket){
        $vals = array(
            "user_id" => $user_id,
            "amount" => $basket->amount
        );
        $this->db->set('create_date', 'NOW()', FALSE);
        $this->db->insert('invoice', $vals);
        return $this->db->insert_id();
    }

    public function get_invoices_by_user_id($user_id){
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('invoice');
        return $query->result();
    }

    public function get_invoice_by_id($id){
        $this->db->where('id', $id);
        $query = $this->db->get('invoice');
        return $query->row();
    }
}

?>
