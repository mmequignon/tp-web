<?php

class Product extends CI_Model{

    public function get_all(){
        $this->db->select('p.*, pc.stockable');
        $this->db->from('product p');
        $this->db->join('product_category pc', 'p.product_category_id = pc.id');
        $this->db->where('p.active', 1);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_product_by_id($id){
        $this->db->select('p.*, pc.stockable');
        $this->db->from('product p');
        $this->db->join('product_category pc', 'p.product_category_id = pc.id');
        $this->db->where('p.id', $id);
        $query = $this->db->get();
        return $query->first_row();
    }

    public function _insert(){
        $data = array(
            "product_category_id" => $this->input->post('product_category_id'),
            "price" => $this->input->post('price'),
            'name' => $this->input->post('name'),
            'stock' => $this->input->post('stock')
        );
        $this->db->insert('product', $data);
    }

    public function _update($id){
        $data = array(
            "product_category_id" => $this->input->post('product_category_id'),
            "price" => $this->input->post('price'),
            'name' => $this->input->post('name'),
            'stock' => $this->input->post('stock')
        );
        $this->db->set($data);
        $this->db->where('id', $id);
        $this->db->update('product');
    }

    public function update_stock($product_id, $product_qty){
        $data = array(
            'stock' => $product_qty
        );
        $this->db->set($data);
        $this->db->where('id', $product_id);
        $this->db->update('product');
    }

    public function _delete($id){
        $this->db->where('id', $id);
        $this->db->delete('product');
    }

    public function _disable($id){
        $this->db->set('active', 0);
        $this->db->where('id', $id);
        $this->db->update('product');
    }

    public function _get_price($id){
        $this->db->select('price');
        $this->db->where('id', $id);
        $query = $this->db->get('product');
        $product = $query->first_row();
        return $product->price;
    }

    public function _get_stock($id){
        $this->db->select('stock');
        $this->db->where('id', $id);
        $query = $this->db->get('product');
        $product = $query->first_row();
        return $product->stock;
    }
}

?>
