<table class="table table-hover" >
    <thead>
      <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach($basket_lines as $basket_line): ?>
        <tr>
            <th><a href="<?php echo site_url('product/item?id='.$basket_line->product_id); ?>"><?php echo $basket_line->name; ?></a> </th>
            <th><?php echo $basket_line->amount; ?></th>
            <th><?php echo $basket_line->product_qty; ?></th>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<form action="<?php echo site_url('basket/checkout'); ?>" method="POST">
    <div class="form-group row">
        <button type="submit" class="btn btn-warning">Checkout</button>
    </div>
</form>
