<?php echo validation_errors(); ?>

<form action="<?php echo site_url('users/update/save'); ?>" method="POST">
    <input name="id" type="hidden" value="<?php echo $user->id; ?>">
    <div class="form-group row">
        <label for="inputLogin">Login</label>
        <input name="login" type="text" class="form-control" id="inputLogin" value="<?php echo $user->login; ?>">
    </div>
    <!--
    <div class="form-group row">
        <label for="inputPassword">Password</label>
        <input name="password" type="password" class="form-control" id="inputPassword" value="<?php echo $password; ?>">
    </div>
    -->
    <div class="form-group row">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" value="<?php echo $user->email; ?>">
    </div>
    <div class="form-group row">
        <label for="inputFirstname">Firstname</label>
        <input name="firstname" type="text" class="form-control" id="inputFirstname" value="<?php echo $user->firstname; ?>">
    </div>
    <div class="form-group row">
        <label for="inputLastname">Lastname</label>
        <input name="lastname" type="text" class="form-control" id="inputLastname" value="<?php echo $user->lastname; ?>">
    </div>
    <div class="form-group row">
        <label for="inputStreet">Street</label>
        <input name="street" type="text" class="form-control" id="inputStreet" placeholder="Enter Street">
    </div>
    <div class="form-group row">
        <label for="inputCity">City</label>
        <input name="city" type="text" class="form-control" id="inputCity" placeholder="Enter City">
    </div>
    <div class="form-group row">
        <label for="inputPostcode">Postal Code</label>
        <input name="postcode" type="number" class="form-control" id="inputPostcode" placeholder="Enter Postal code">
    </div>
    <div class="form-group row">
        <button type="submit" class="btn btn-warning">Update</button>
    </div>
</form>
<h2>Your orders</h2>
<table class="table table-hover" >
    <thead>
      <tr>
        <th>Number</th>
        <th>Amount</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach($orders as $order): ?>
        <tr>
            <th><a href="<?php echo site_url('invoice/order?id='.$order->id); ?>"><?php echo $order->id; ?></a> </th>
            <th><?php echo $order->amount; ?></th>
            <th><?php echo $order->create_date; ?></th>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
