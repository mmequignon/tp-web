<?php echo validation_errors(); ?>

<form action="<?php echo site_url('users/register/save'); ?>" method="POST">
    <div class="form-group row">
        <label for="inputLogin">Login</label>
        <input name="login" type="text" class="form-control" id="inputLogin" placeholder="Enter Login">
    </div>
    <div class="form-group row">
        <label for="inputPassword">Password</label>
        <input name="password" type="password" class="form-control" id="inputPassword" placeholder="Enter password">
    </div>
    <div class="form-group row">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
    </div>
    <div class="form-group row">
        <label for="inputFirstname">Firstname</label>
        <input name="firstname" type="text" class="form-control" id="inputFirstname" placeholder="Enter Firstname">
    </div>
    <div class="form-group row">
        <label for="inputLastname">Lastname</label>
        <input name="lastname" type="text" class="form-control" id="inputLastname" placeholder="Enter Lastname">
    </div>
    <div class="form-group row">
        <label for="inputStreet">Street</label>
        <input name="street" type="text" class="form-control" id="inputStreet" placeholder="Enter Street">
    </div>
    <div class="form-group row">
        <label for="inputCity">City</label>
        <input name="city" type="text" class="form-control" id="inputCity" placeholder="Enter City">
    </div>
    <div class="form-group row">
        <label for="inputPostcode">Postal Code</label>
        <input name="postcode" type="number" class="form-control" id="inputPostcode" placeholder="Enter Postal code">
    </div>
    <div class="form-check row">
        <label for="inputAdmin">Admin</label>
        <input name="admin" id="checkboxAdmin" class="form-check-input" type="checkbox" value="1" <?php echo ($admin == FALSE) ? 'style="display:none;"': ''; ?>>
    </div>
    <div class="form-group row">
        <button type="submit" class="btn btn-warning">Create</button>
    </div>
</form>
