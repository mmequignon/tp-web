<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	public function index(){
        $this->load->library('session');
        $this->load->model('Invoice');
        $this->load->model('InvoiceLine');
        $this->load->model('Users');
        $admin = $this->session->userdata('admin');
        $logged = $this->session->userdata('logged');
        $current_user_id = $this->session->userdata('id');
        $invoice_id = $this->input->get('id');
        $invoice = $this->Invoice->get_invoice_by_id($invoice_id);
        $invoice_lines = $this->InvoiceLine->get_invoice_lines_by_invoice_id($invoice_id);
        $user = $this->Users->get_user_by_id($invoice->user_id);
        if ((! $admin) || (! $user->id == $current_user_id)){
            show_404();
        }
        $data = array(
            "page" => "account",
            "title" => "Invoice No : ".$invoice->id,
            "invoice" => $invoice,
            "invoice_lines" => $invoice_lines,
            "user" => $user,
            "logged" => $logged,
            "admin" => $admin
        );
        $this->load->view('base/header', $data );
        $this->load->view('invoice/invoice', $data );
        $this->load->view('base/footer');
    }
}
