<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Update extends CI_Controller {

	public function index(){
        $this->load->library('session');
        $this->load->model('Users');
        $this->load->model('Invoice');
        $admin = $this->session->userdata('admin'); 
        $logged = $this->session->userdata('logged');
        $user_id = $this->input->post('id');
        $current_user_id = $this->session->userdata('id');
        if((! $admin) || (! $user_id == $current_user_id)){
            show_404();
        }
        $user = $this->Users->get_user_by_id($user_id);
        $orders = $this->Invoice->get_invoices_by_user_id($user_id);
        $data = array(
            "page" => "users",
            "title" => "Update",
            "user" => $user,
            "orders" => $orders,
            "logged" => $logged,
            "admin" => $admin
        );
        $this->load->view('base/header', $data);
        $this->load->view('users/update', $data);
        $this->load->view('base/footer');
	}

    public function save(){
        $this->form_validation->set_rules('login', 'Login', 'trim|required');
        // $this->form_validation->set_rules('password', 'Password', 'trim|required');
        // TODO LADDER
        $this->form_validation->set_rules('email', 'E-Mail', 'trim|required|valid_email');
        if ($this->form_validation->run()){
            $this->load->model('Users');
            $this->Users->_update($this->input->post('id'));
            redirect('users/liste', 'refresh');
        }
        else{
            $this->index();
        }
    }
}
