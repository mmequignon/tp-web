<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Liste extends CI_Controller {

	public function index(){
        // On récupère les informations de la session courante
        // afin de les passer aux vues
        $this->load->library('session');
        $admin = $this->session->userdata('admin'); 
        $logged = $this->session->userdata('logged'); 
        // Appel de la méthode permettant de récupérer tous
        // les produits.
        $this->load->model('Product');
        $products = $this->Product->get_all();

        $data = array(
            "page" => "product",
            "title" => "Products",
            "products" => $products,
            "logged" => $logged,
            "admin" => $admin
        );

		$this->load->view('base/header', $data);
		$this->load->view('product/liste', $data);
		$this->load->view('base/footer');
	}

    public function filter(){
    }
}
