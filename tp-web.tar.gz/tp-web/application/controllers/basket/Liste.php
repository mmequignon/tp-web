<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Liste extends CI_Controller {

	public function index(){
        // On récupère les informations de la session courante
        // afin de les passer aux vues
        $this->load->library('session');
        $user_id = $this->session->userdata('id');
        $admin = $this->session->userdata('admin'); 
        $logged = $this->session->userdata('logged'); 
        $basket_id = $this->session->userdata('basket');
        // Récupération du panier et des lignes de panier actives de l'utilisateur courant
        $this->load->model('Basket');
        $basket_lines = $this->Basket->get_basket_lines_by_basket_id($basket_id);
        $basket = $this->Basket->get_basket($basket_id);
        $amount = $basket->amount;

        $data = array(
            "page" => "basket",
            "title" => "Basket - Total : ".$amount."€",
            "logged" => $logged,
            "basket_lines" => $basket_lines,
            "amount" => $amount,
            "admin" => $admin,
            "basket_id" => $basket_id,
            "user_id" => $user_id
        );

		$this->load->view('base/header', $data);
		$this->load->view('basket/liste', $data);
		$this->load->view('base/footer');
	}
}
