<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class checkout extends CI_Controller {

	public function index(){
        // On récupère les informations de la session courante
        // afin de les passer aux vues
        $this->load->library('session');
        $user_id = $this->session->userdata('id');
        $basket_id = $this->session->userdata('basket');
        // Récupération du panier et des lignes de panier actives de l'utilisateur courant
        $this->load->model('Basket');
        $this->load->model('Invoice');
        $this->load->model('InvoiceLine');
        $this->load->model('BasketLine');
        $basket = $this->Basket->get_basket($basket_id);
        $invoice_id = $this->Invoice->basket_to_invoice($user_id, $basket);
        $basket_lines = $this->Basket->get_basket_lines_by_basket_id($basket_id);
        // Création d'une ligne de facture pour chaque ligne de panier active
        foreach($basket_lines as $basket_line){
            $this->InvoiceLine->basket_line_to_invoice_line($invoice_id, $basket_line);
            $this->BasketLine->disable($basket_line->id);
        }
        $this->Basket->_reset($basket->id);
        redirect('basket/liste');
	}
}
