<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

abstract class Private extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->library('session');
        $admin = $this->session->userdata('admin'); 
        $user_id
        if (! ($admin) || ! != 1 ){
            show_404();
        }
    }
}
